import UIKit

// Data Types
var vediosGames: Int = 0 // Integer
var point: Float = 1.1 // upto 6 dec
var points: Double = 22.22 // upto 15 dec
var course: String = "Swift" // String
var buldOn: Bool = true // boolean
var numbers = 100 // type infrences

// Variables
let highScore = 0 // constant, cannont be asign further or change
var name = "Haseeb"
name = "Haseeb Khan" // can be change becauseit is Var

// Array: Ordered
var arrayAges  = [21, 33, 45, 71, 22]
var arrayEmpty: [Int] = [] // empty array
arrayAges.count // counting items
arrayAges.first // first item
arrayAges.last // last item
arrayAges[0] // print 0 index
arrayAges.append(99) // append in end
arrayAges.insert(44, at: 2) // insert in specific index
arrayAges.sort() // sort array
arrayAges.reverse() // reverse array
arrayAges.shuffle() // shuffle array

// Set: Unordered, no duplicate => Performance fast
var setAges = [14, 55, 26, 71, 55, 26]
var setEmpty: Set<Int> = [] // empty set
var set = Set(setAges) // created set with array
set.contains(26) // true
set.insert(101) // inserted

// Dictionary: Collection  of keys, values
let devices : [String:  String] = [
    "Phone": "IPhoneX",
    "Mac":   "MacBook Pro",
    "Bike":  "Honda CD70"
]
devices["Mac"] // passing key to get value

// Functions , we can also use func inside func
func printNames() { // scope of func
    print("Haseeb Khan")
}
printNames() // call the func
func printInstructor(name: String) { // parameter: name
    print(name)
}
printInstructor(name: "Sean Allen")
func add(first: Int, to second: Int) -> Int { // -> return, to argument label
    let sum = first + second
    return sum
}
add(first: 10, to: 30)

// if/else : condition
var darkModeisOn = true
if darkModeisOn == true{
    print("Dark Mode is On")
} else {
    print("Off")
}

var myMarks = 555
if myMarks > 500 {
    print("Best")
} else if myMarks > 250 {
    print("Avg")
} else {
    print("U need inprovement")
}

// For Loops : iterate over a collection
let allStars = ["Afridi", "Kholi", "Amir", "Rohit"]
for player in allStars{ // where player == "Amir", that print only Amir
    print(player)
}
for i in 0..<25{ // range 25 times
    print(i)
}
var randomInt: [Int] = []
for _ in 0..<25{
    let randomNum = Int.random(in: 0...100)
    randomInt.append(randomNum)
}
print(randomInt)

// Enumeration: Group of values related
enum Devices: String{
    case iOS     = "Iphone"  // asignning rawvalues
    case macOS   = "MacBook"
    case watchOS = "Smart"
    case tvOS    = "AppleTv"
}
func getDevice(on device: Devices){
    print(device.rawValue)  // rawvalues
}
getDevice(on: .iOS)

// Switch Statements
enum AppleStore: String{
    case iOS
    case macOS
    case watchOS
    case tvOS
}
func getShop(on product: AppleStore){
    switch product {
    case .iOS:
        print("Iphone")
    case .macOS:
        print("MacBook")
    case .watchOS:
        print("Smart")
    case .tvOS:
        print("TV")
    }
}
getShop(on: .iOS)

// Operator:
// Arithemetic: + - * / %
// Assignment: < > <= >=
// Logical: ! == && || , && means both, || means one

let valueOne = 55
let valueTwo = 88
let mode = true
let sum = valueOne - valueTwo
if valueOne != valueTwo { // Bang Operator
    print("Not Equal")
}
if valueOne >= valueTwo || mode{
    print("On")
}

var counter = 1
counter += 1 // increace by one

let hi = "Hello"
let greet = "Good to see U"

print(hi + " " + greet)

// Optional: Absence of value
var bac: [Int] = []
// if let
if let baz = bac.last{
    print("Last \(bac)")  // nill
} else {
    print("No ")
}
// let baz = bac.last ?? 999
// guard
// force unwrap
// let baz = bac.last!


// Classes: refrence type
class Developer{
    var name: String
    var job: String
    var exp: Int
    
    init(name: String, job: String, exp: Int) { // initilizers
        // self
        self.name = name
        self.job = job
        self.exp = exp
    }
    func speakName(){
        print(name)
    }
}
let haseeb = Developer(name: "Haseeb", job: "iOS", exp: 4)
haseeb.speakName()

// Inheritance: inherit properties from parent
class Employees: Developer{
    var framework: String = "Jhango"
    
    func speakFramework(){
        print(framework)
    }
}
let empl = Employees(name: "Joe", job: "SE", exp: 3)
empl.speakFramework()
empl.speakName()

// Structure: value type , no initilizers
struct Person{
    var height: Float
    var weight: Float
}
var man1 = Person(height: 5.5, weight: 65.0)
man1.height = 6.0

// Extension: Add Custom functionality
extension String {
    func removeWhiteSpace() -> String {
        return components(separatedBy: .whitespaces).joined()
        
    }
}
let alpha  = "A B C"
print(alpha.removeWhiteSpace())
